

#ifdef __cplusplus
extern "C" {  
#endif
    void readFile(const char* key);

    void writeFile(const char* key);
#ifdef __cplusplus
}
#endif


